Online Help HTML Templates

These templates 1were originally designed for ClickHelp, an online documentation tool. However, you can use them with any other tool. The HTML uses responsive styles which support any devices from mobile phone to a widescreen monitor.

Detailed license can be found in license.txt. Its general idea is simple: you are free to use the templates to create your own documentation, but you cannot redistribute the templates in their original or modified form.

Find more useful downloads, including a free ebook on responsive HTML design, at our website:
https://clickhelp.com
1 Disclaimer: This e-book is designed for information purposes only. The publisher and the author(s) is not engaged to render any type of psychological, legal, or any other kind of professional advice. The content of each article is the sole expression and opinion of its author(s) and publisher. No warranties or guarantees are expressed or implied with this e-book. Neither the publisher nor the individual author(s) shall be liable for any physical, psychological, emotional, financial, or commercial issues, including, but not limited to, special, incidental, consequential or other issues. You are responsible for your own choices, actions, and results that might arise due to the use or misuse of this e-book.
---------------

------------------------------------------------------------

---------------

------------------------------------------------------------

